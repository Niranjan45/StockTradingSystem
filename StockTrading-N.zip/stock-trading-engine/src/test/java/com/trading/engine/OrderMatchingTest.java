package com.trading.engine;

import com.trading.engine.dto.request.OrderRequests.PlaceOrderRequest;
import com.trading.engine.dto.response.Responses.OrderResponse;
import com.trading.engine.dto.response.Responses.TradeResponse;
import com.trading.engine.enums.OrderStatus;
import com.trading.engine.service.OrderService;
import com.trading.engine.service.TradeService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("test")
class OrderMatchingTest {

    @Autowired OrderService orderService;
    @Autowired TradeService tradeService;

    @Test
    void fullMatchGeneratesTrade() {
        // User 1 (Alice, id=1) buys 100 AAPL at 200
        PlaceOrderRequest buy = PlaceOrderRequest.builder()
                .userId(1L).symbol("AAPL")
                .price(new BigDecimal("200.00")).quantity(100).build();
        OrderResponse buyResp = orderService.placeBuyOrder(buy);
        assertThat(buyResp.getStatus()).isIn(OrderStatus.OPEN, OrderStatus.FILLED);

        // User 2 (Bob, id=2) sells 100 AAPL at 200
        PlaceOrderRequest sell = PlaceOrderRequest.builder()
                .userId(2L).symbol("AAPL")
                .price(new BigDecimal("200.00")).quantity(100).build();
        OrderResponse sellResp = orderService.placeSellOrder(sell);
        assertThat(sellResp.getStatus()).isEqualTo(OrderStatus.FILLED);

        List<TradeResponse> trades = tradeService.getTradesByStock("AAPL");
        assertThat(trades).isNotEmpty();
        TradeResponse latest = trades.get(0);
        assertThat(latest.getQuantity()).isEqualTo(100);
        assertThat(latest.getPrice()).isEqualByComparingTo("200.00");
    }

    @Test
    void partialMatchUpdatesRemainingQuantity() {
        PlaceOrderRequest buy = PlaceOrderRequest.builder()
                .userId(1L).symbol("MSFT")
                .price(new BigDecimal("300.00")).quantity(200).build();
        orderService.placeBuyOrder(buy);

        PlaceOrderRequest sell = PlaceOrderRequest.builder()
                .userId(2L).symbol("MSFT")
                .price(new BigDecimal("300.00")).quantity(100).build();
        OrderResponse sellResp = orderService.placeSellOrder(sell);

        assertThat(sellResp.getStatus()).isEqualTo(OrderStatus.FILLED);
        assertThat(sellResp.getRemainingQuantity()).isZero();
    }
}
