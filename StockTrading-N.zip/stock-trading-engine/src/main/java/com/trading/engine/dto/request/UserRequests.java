package com.trading.engine.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;

// ── User ──────────────────────────────────────────────────────────────────────
public class UserRequests {

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class RegisterUserRequest {

        @NotBlank(message = "Name is required")
        @Size(min = 2, max = 100)
        private String name;

        @NotBlank(message = "Email is required")
        @Email(message = "Invalid email format")
        private String email;

        @NotNull(message = "Initial balance is required")
        @DecimalMin(value = "0.0", inclusive = false, message = "Balance must be positive")
        @Digits(integer = 15, fraction = 4)
        private BigDecimal balance;
    }
}
