package com.trading.engine.enums;

public enum OrderStatus {
    OPEN,
    PARTIAL,
    FILLED,
    CANCELLED
}
