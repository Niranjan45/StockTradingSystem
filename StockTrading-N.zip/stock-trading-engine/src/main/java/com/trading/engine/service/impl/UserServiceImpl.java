package com.trading.engine.service.impl;

import com.trading.engine.dto.request.UserRequests.RegisterUserRequest;
import com.trading.engine.dto.response.Responses.UserResponse;
import com.trading.engine.entity.User;
import com.trading.engine.exception.BusinessException;
import com.trading.engine.exception.ResourceNotFoundException;
import com.trading.engine.repository.UserRepository;
import com.trading.engine.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Override
    @Transactional
    public UserResponse registerUser(RegisterUserRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BusinessException("Email already registered: " + request.getEmail());
        }
        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .balance(request.getBalance())
                .build();
        User saved = userRepository.save(user);
        log.info("Registered new user: id={}, email={}", saved.getId(), saved.getEmail());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public UserResponse getUserById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    // ── helpers ───────────────────────────────────────────────────────────────
    public User findOrThrow(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
    }

    private UserResponse toResponse(User u) {
        return UserResponse.builder()
                .id(u.getId())
                .name(u.getName())
                .email(u.getEmail())
                .balance(u.getBalance())
                .createdAt(u.getCreatedAt())
                .build();
    }
}
