package com.trading.engine.config;

import com.trading.engine.entity.Stock;
import com.trading.engine.entity.User;
import com.trading.engine.repository.StockRepository;
import com.trading.engine.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final StockRepository stockRepository;
    private final UserRepository  userRepository;

    @Override
    public void run(String... args) {
        seedStocks();
        seedUsers();
    }

    private void seedStocks() {
        if (stockRepository.count() > 0) return;
        List<Stock> stocks = List.of(
            Stock.builder().symbol("AAPL").companyName("Apple Inc.").build(),
            Stock.builder().symbol("GOOGL").companyName("Alphabet Inc.").build(),
            Stock.builder().symbol("MSFT").companyName("Microsoft Corporation").build(),
            Stock.builder().symbol("AMZN").companyName("Amazon.com Inc.").build(),
            Stock.builder().symbol("TSLA").companyName("Tesla Inc.").build()
        );
        stockRepository.saveAll(stocks);
        log.info("Seeded {} stocks", stocks.size());
    }

    private void seedUsers() {
        if (userRepository.count() > 0) return;
        List<User> users = List.of(
            User.builder().name("Alice").email("alice@trading.com")
                .balance(new BigDecimal("100000.00")).build(),
            User.builder().name("Bob").email("bob@trading.com")
                .balance(new BigDecimal("100000.00")).build()
        );
        userRepository.saveAll(users);
        log.info("Seeded {} demo users", users.size());
    }
}
