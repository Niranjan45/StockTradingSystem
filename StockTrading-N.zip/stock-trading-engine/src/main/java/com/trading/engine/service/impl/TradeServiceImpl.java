package com.trading.engine.service.impl;

import com.trading.engine.dto.response.Responses.TradeResponse;
import com.trading.engine.entity.Stock;
import com.trading.engine.entity.Trade;
import com.trading.engine.repository.TradeRepository;
import com.trading.engine.service.TradeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class TradeServiceImpl implements TradeService {

    private final TradeRepository  tradeRepository;
    private final StockServiceImpl stockService;
    private final UserServiceImpl  userService;

    @Override
    @Transactional(readOnly = true)
    public List<TradeResponse> getTradesByStock(String symbol) {
        Stock stock = stockService.findOrThrow(symbol);
        return tradeRepository.findRecentTradesByStock(stock)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<TradeResponse> getTradesByUser(Long userId) {
        userService.findOrThrow(userId);
        return tradeRepository.findTradesByUserId(userId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    // ── helpers ───────────────────────────────────────────────────────────────
    private TradeResponse toResponse(Trade t) {
        return TradeResponse.builder()
                .id(t.getId())
                .buyOrderId(t.getBuyOrder().getId())
                .sellOrderId(t.getSellOrder().getId())
                .stockSymbol(t.getBuyOrder().getStock().getSymbol())
                .price(t.getPrice())
                .quantity(t.getQuantity())
                .executedAt(t.getExecutedAt())
                .build();
    }
}
