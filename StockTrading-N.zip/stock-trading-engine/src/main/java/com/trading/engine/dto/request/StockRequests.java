package com.trading.engine.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

public class StockRequests {

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class CreateStockRequest {

        @NotBlank(message = "Symbol is required")
        @Size(min = 1, max = 20)
        @Pattern(regexp = "^[A-Z]+$", message = "Symbol must be uppercase letters only")
        private String symbol;

        @NotBlank(message = "Company name is required")
        @Size(min = 2, max = 200)
        private String companyName;
    }
}
