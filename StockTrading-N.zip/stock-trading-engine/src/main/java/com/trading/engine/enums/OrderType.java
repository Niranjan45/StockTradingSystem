package com.trading.engine.enums;

public enum OrderType {
    BUY,
    SELL
}
