package com.trading.engine.controller;

import com.trading.engine.dto.response.Responses.*;
import com.trading.engine.service.TradeService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/trades")
@RequiredArgsConstructor
@Tag(name = "Trades", description = "View executed trades")
public class TradeController {

    private final TradeService tradeService;

    @GetMapping("/stock/{symbol}")
    @Operation(summary = "Get recent trades for a stock")
    public ResponseEntity<ApiResponse<List<TradeResponse>>> getByStock(@PathVariable String symbol) {
        return ResponseEntity.ok(ApiResponse.ok(tradeService.getTradesByStock(symbol)));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get all trades for a user")
    public ResponseEntity<ApiResponse<List<TradeResponse>>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok(tradeService.getTradesByUser(userId)));
    }
}
