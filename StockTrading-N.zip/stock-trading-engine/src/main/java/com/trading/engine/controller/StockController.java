package com.trading.engine.controller;

import com.trading.engine.dto.request.StockRequests.CreateStockRequest;
import com.trading.engine.dto.response.Responses.*;
import com.trading.engine.service.StockService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/stocks")
@RequiredArgsConstructor
@Tag(name = "Stocks", description = "Stock listing and creation")
public class StockController {

    private final StockService stockService;

    @PostMapping
    @Operation(summary = "Create / list a new stock")
    public ResponseEntity<ApiResponse<StockResponse>> create(
            @Valid @RequestBody CreateStockRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Stock created", stockService.createStock(request)));
    }

    @GetMapping
    @Operation(summary = "List all stocks")
    public ResponseEntity<ApiResponse<List<StockResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.ok(stockService.getAllStocks()));
    }

    @GetMapping("/{symbol}")
    @Operation(summary = "Get stock by symbol")
    public ResponseEntity<ApiResponse<StockResponse>> getBySymbol(@PathVariable String symbol) {
        return ResponseEntity.ok(ApiResponse.ok(stockService.getStockBySymbol(symbol)));
    }
}
