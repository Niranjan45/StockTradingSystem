package com.trading.engine.service.impl;

import com.trading.engine.dto.request.StockRequests.CreateStockRequest;
import com.trading.engine.dto.response.Responses.StockResponse;
import com.trading.engine.entity.Stock;
import com.trading.engine.exception.BusinessException;
import com.trading.engine.exception.ResourceNotFoundException;
import com.trading.engine.repository.StockRepository;
import com.trading.engine.service.StockService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class StockServiceImpl implements StockService {

    private final StockRepository stockRepository;

    @Override
    @Transactional
    public StockResponse createStock(CreateStockRequest request) {
        if (stockRepository.existsBySymbol(request.getSymbol())) {
            throw new BusinessException("Stock already exists with symbol: " + request.getSymbol());
        }
        Stock stock = Stock.builder()
                .symbol(request.getSymbol())
                .companyName(request.getCompanyName())
                .build();
        Stock saved = stockRepository.save(stock);
        log.info("Created stock: symbol={}", saved.getSymbol());
        return toResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public StockResponse getStockBySymbol(String symbol) {
        return toResponse(findOrThrow(symbol));
    }

    @Override
    @Transactional(readOnly = true)
    public List<StockResponse> getAllStocks() {
        return stockRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    // ── helpers ───────────────────────────────────────────────────────────────
    public Stock findOrThrow(String symbol) {
        return stockRepository.findBySymbol(symbol.toUpperCase())
                .orElseThrow(() -> new ResourceNotFoundException("Stock not found: " + symbol));
    }

    private StockResponse toResponse(Stock s) {
        return StockResponse.builder()
                .id(s.getId())
                .symbol(s.getSymbol())
                .companyName(s.getCompanyName())
                .build();
    }
}
