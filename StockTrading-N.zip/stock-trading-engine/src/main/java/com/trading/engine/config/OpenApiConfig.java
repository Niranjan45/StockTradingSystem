package com.trading.engine.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI tradingEngineOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("Stock Trading Order Engine API")
                        .description("Backend API for a simplified stock exchange — place orders, " +
                                "view the order book, and inspect executed trades.")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("Trading Engine Team")
                                .email("dev@trading.com"))
                        .license(new License()
                                .name("MIT")
                                .url("https://opensource.org/licenses/MIT")));
    }
}
