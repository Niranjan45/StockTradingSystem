package com.trading.engine.repository;

import com.trading.engine.entity.Order;
import com.trading.engine.entity.Stock;
import com.trading.engine.enums.OrderStatus;
import com.trading.engine.enums.OrderType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface OrderRepository extends JpaRepository<Order, Long> {

    List<Order> findByUserIdOrderByCreatedAtDesc(Long userId);

    /**
     * Matching SELL orders: price <= buyPrice, status OPEN/PARTIAL, ordered by price ASC then time ASC (FIFO)
     */
    @Query("""
        SELECT o FROM Order o
        WHERE o.stock = :stock
          AND o.orderType = 'SELL'
          AND o.status IN ('OPEN', 'PARTIAL')
          AND o.price <= :buyPrice
        ORDER BY o.price ASC, o.createdAt ASC
        """)
    List<Order> findMatchingSellOrders(@Param("stock") Stock stock,
                                       @Param("buyPrice") BigDecimal buyPrice);

    /**
     * Matching BUY orders: price >= sellPrice, status OPEN/PARTIAL, ordered by price DESC then time ASC (FIFO)
     */
    @Query("""
        SELECT o FROM Order o
        WHERE o.stock = :stock
          AND o.orderType = 'BUY'
          AND o.status IN ('OPEN', 'PARTIAL')
          AND o.price >= :sellPrice
        ORDER BY o.price DESC, o.createdAt ASC
        """)
    List<Order> findMatchingBuyOrders(@Param("stock") Stock stock,
                                      @Param("sellPrice") BigDecimal sellPrice);

    /**
     * Market depth: top N BUY orders (highest price first)
     */
    @Query("""
        SELECT o FROM Order o
        WHERE o.stock = :stock
          AND o.orderType = 'BUY'
          AND o.status IN ('OPEN', 'PARTIAL')
        ORDER BY o.price DESC, o.createdAt ASC
        """)
    List<Order> findTopBuyOrders(@Param("stock") Stock stock);

    /**
     * Market depth: top N SELL orders (lowest price first)
     */
    @Query("""
        SELECT o FROM Order o
        WHERE o.stock = :stock
          AND o.orderType = 'SELL'
          AND o.status IN ('OPEN', 'PARTIAL')
        ORDER BY o.price ASC, o.createdAt ASC
        """)
    List<Order> findTopSellOrders(@Param("stock") Stock stock);

    List<Order> findByStockAndOrderTypeAndStatusIn(
        Stock stock, OrderType orderType, List<OrderStatus> statuses);
}
