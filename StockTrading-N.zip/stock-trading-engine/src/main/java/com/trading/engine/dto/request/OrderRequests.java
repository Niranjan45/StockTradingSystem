package com.trading.engine.dto.request;

import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;

public class OrderRequests {

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class PlaceOrderRequest {

        @NotNull(message = "User ID is required")
        @Positive(message = "User ID must be positive")
        private Long userId;

        @NotBlank(message = "Stock symbol is required")
        @Size(min = 1, max = 20)
        private String symbol;

        @NotNull(message = "Price is required")
        @DecimalMin(value = "0.01", message = "Price must be at least 0.01")
        @Digits(integer = 15, fraction = 4)
        private BigDecimal price;

        @NotNull(message = "Quantity is required")
        @Min(value = 1, message = "Quantity must be at least 1")
        private Integer quantity;
    }
}
