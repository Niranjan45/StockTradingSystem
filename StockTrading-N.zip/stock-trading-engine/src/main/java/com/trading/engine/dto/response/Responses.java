package com.trading.engine.dto.response;

import com.trading.engine.enums.OrderStatus;
import com.trading.engine.enums.OrderType;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class Responses {

    // ── Generic API Wrapper ────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class ApiResponse<T> {
        private boolean success;
        private String message;
        private T data;

        public static <T> ApiResponse<T> ok(T data) {
            return ApiResponse.<T>builder().success(true).message("OK").data(data).build();
        }
        public static <T> ApiResponse<T> ok(String message, T data) {
            return ApiResponse.<T>builder().success(true).message(message).data(data).build();
        }
        public static <T> ApiResponse<T> error(String message) {
            return ApiResponse.<T>builder().success(false).message(message).build();
        }
    }

    // ── User ──────────────────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class UserResponse {
        private Long id;
        private String name;
        private String email;
        private BigDecimal balance;
        private LocalDateTime createdAt;
    }

    // ── Stock ─────────────────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class StockResponse {
        private Long id;
        private String symbol;
        private String companyName;
    }

    // ── Order ─────────────────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class OrderResponse {
        private Long id;
        private Long userId;
        private String userName;
        private String stockSymbol;
        private OrderType orderType;
        private BigDecimal price;
        private Integer quantity;
        private Integer remainingQuantity;
        private OrderStatus status;
        private LocalDateTime createdAt;
    }

    // ── Trade ─────────────────────────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class TradeResponse {
        private Long id;
        private Long buyOrderId;
        private Long sellOrderId;
        private String stockSymbol;
        private BigDecimal price;
        private Integer quantity;
        private LocalDateTime executedAt;
    }

    // ── Order Book (Market Depth) ─────────────────────────────────────────────
    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class OrderBookResponse {
        private String symbol;
        private List<OrderBookEntry> bids;   // BUY orders
        private List<OrderBookEntry> asks;   // SELL orders
    }

    @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
    public static class OrderBookEntry {
        private BigDecimal price;
        private Integer totalQuantity;
        private Integer orderCount;
    }
}
