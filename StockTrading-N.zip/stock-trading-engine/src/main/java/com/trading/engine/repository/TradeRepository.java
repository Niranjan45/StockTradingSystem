package com.trading.engine.repository;

import com.trading.engine.entity.Stock;
import com.trading.engine.entity.Trade;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TradeRepository extends JpaRepository<Trade, Long> {

    @Query("""
        SELECT t FROM Trade t
        WHERE t.buyOrder.stock = :stock
        ORDER BY t.executedAt DESC
        """)
    List<Trade> findRecentTradesByStock(@Param("stock") Stock stock);

    @Query("""
        SELECT t FROM Trade t
        WHERE t.buyOrder.user.id = :userId OR t.sellOrder.user.id = :userId
        ORDER BY t.executedAt DESC
        """)
    List<Trade> findTradesByUserId(@Param("userId") Long userId);
}
