package com.trading.engine.service;

import com.trading.engine.dto.request.StockRequests.CreateStockRequest;
import com.trading.engine.dto.response.Responses.StockResponse;

import java.util.List;

public interface StockService {
    StockResponse createStock(CreateStockRequest request);
    StockResponse getStockBySymbol(String symbol);
    List<StockResponse> getAllStocks();
}
