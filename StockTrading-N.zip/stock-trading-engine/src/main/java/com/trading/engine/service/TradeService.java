package com.trading.engine.service;

import com.trading.engine.dto.response.Responses.TradeResponse;
import java.util.List;

public interface TradeService {
    List<TradeResponse> getTradesByStock(String symbol);
    List<TradeResponse> getTradesByUser(Long userId);
}
