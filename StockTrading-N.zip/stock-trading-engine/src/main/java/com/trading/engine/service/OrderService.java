package com.trading.engine.service;

import com.trading.engine.dto.request.OrderRequests.PlaceOrderRequest;
import com.trading.engine.dto.response.Responses.OrderBookResponse;
import com.trading.engine.dto.response.Responses.OrderResponse;

import java.util.List;

public interface OrderService {
    OrderResponse placeBuyOrder(PlaceOrderRequest request);
    OrderResponse placeSellOrder(PlaceOrderRequest request);
    OrderResponse cancelOrder(Long orderId, Long userId);
    List<OrderResponse> getUserOrders(Long userId);
    OrderBookResponse getOrderBook(String symbol);
}
