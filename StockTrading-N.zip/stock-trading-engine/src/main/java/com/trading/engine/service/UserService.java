package com.trading.engine.service;

import com.trading.engine.dto.request.UserRequests.RegisterUserRequest;
import com.trading.engine.dto.response.Responses.UserResponse;

import java.util.List;

public interface UserService {
    UserResponse registerUser(RegisterUserRequest request);
    UserResponse getUserById(Long id);
    List<UserResponse> getAllUsers();
}
