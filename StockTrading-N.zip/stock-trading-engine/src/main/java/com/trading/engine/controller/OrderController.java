package com.trading.engine.controller;

import com.trading.engine.dto.request.OrderRequests.PlaceOrderRequest;
import com.trading.engine.dto.response.Responses.*;
import com.trading.engine.service.OrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/orders")
@RequiredArgsConstructor
@Tag(name = "Orders", description = "Place, cancel, and view orders")
public class OrderController {

    private final OrderService orderService;

    @PostMapping("/buy")
    @Operation(summary = "Place a BUY order")
    public ResponseEntity<ApiResponse<OrderResponse>> placeBuyOrder(
            @Valid @RequestBody PlaceOrderRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Buy order placed", orderService.placeBuyOrder(request)));
    }

    @PostMapping("/sell")
    @Operation(summary = "Place a SELL order")
    public ResponseEntity<ApiResponse<OrderResponse>> placeSellOrder(
            @Valid @RequestBody PlaceOrderRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Sell order placed", orderService.placeSellOrder(request)));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Cancel an open order")
    public ResponseEntity<ApiResponse<OrderResponse>> cancelOrder(
            @PathVariable Long id,
            @Parameter(description = "ID of the user who placed the order")
            @RequestParam Long userId) {
        return ResponseEntity.ok(ApiResponse.ok("Order cancelled", orderService.cancelOrder(id, userId)));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get order history for a user")
    public ResponseEntity<ApiResponse<List<OrderResponse>>> getUserOrders(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.ok(orderService.getUserOrders(userId)));
    }

    @GetMapping("/orderbook/{symbol}")
    @Operation(summary = "Get market depth (order book) for a stock")
    public ResponseEntity<ApiResponse<OrderBookResponse>> getOrderBook(@PathVariable String symbol) {
        return ResponseEntity.ok(ApiResponse.ok(orderService.getOrderBook(symbol)));
    }
}
