package com.trading.engine.service.impl;

import com.trading.engine.dto.request.OrderRequests.PlaceOrderRequest;
import com.trading.engine.dto.response.Responses.*;
import com.trading.engine.entity.*;
import com.trading.engine.enums.OrderStatus;
import com.trading.engine.enums.OrderType;
import com.trading.engine.exception.BusinessException;
import com.trading.engine.exception.ResourceNotFoundException;
import com.trading.engine.repository.OrderRepository;
import com.trading.engine.repository.TradeRepository;
import com.trading.engine.repository.UserRepository;
import com.trading.engine.service.OrderService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class OrderServiceImpl implements OrderService {

    private final OrderRepository   orderRepository;
    private final TradeRepository   tradeRepository;
    private final UserRepository    userRepository;
    private final UserServiceImpl   userService;
    private final StockServiceImpl  stockService;

    // Per-stock lock map to ensure concurrency-safe matching
    private final ConcurrentHashMap<String, ReentrantLock> stockLocks = new ConcurrentHashMap<>();

    // ── Public API ────────────────────────────────────────────────────────────

    @Override
    public OrderResponse placeBuyOrder(PlaceOrderRequest request) {
        return placeOrder(request, OrderType.BUY);
    }

    @Override
    public OrderResponse placeSellOrder(PlaceOrderRequest request) {
        return placeOrder(request, OrderType.SELL);
    }

    @Override
    @Transactional
    public OrderResponse cancelOrder(Long orderId, Long userId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found: " + orderId));

        if (!order.getUser().getId().equals(userId)) {
            throw new BusinessException("You can only cancel your own orders");
        }
        if (order.getStatus() == OrderStatus.FILLED || order.getStatus() == OrderStatus.CANCELLED) {
            throw new BusinessException("Cannot cancel an order in status: " + order.getStatus());
        }

        order.setStatus(OrderStatus.CANCELLED);
        orderRepository.save(order);
        log.info("Order {} cancelled by user {}", orderId, userId);
        return toResponse(order);
    }

    @Override
    @Transactional(readOnly = true)
    public List<OrderResponse> getUserOrders(Long userId) {
        userService.findOrThrow(userId);
        return orderRepository.findByUserIdOrderByCreatedAtDesc(userId)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public OrderBookResponse getOrderBook(String symbol) {
        Stock stock = stockService.findOrThrow(symbol);

        List<Order> buyOrders  = orderRepository.findTopBuyOrders(stock);
        List<Order> sellOrders = orderRepository.findTopSellOrders(stock);

        return OrderBookResponse.builder()
                .symbol(symbol.toUpperCase())
                .bids(aggregateEntries(buyOrders))
                .asks(aggregateEntries(sellOrders))
                .build();
    }

    // ── Core matching engine ──────────────────────────────────────────────────

    /**
     * Places an order inside a per-stock lock, then immediately tries to match it.
     * The entire operation (persist + match + persist trades) runs in one transaction.
     */
    private OrderResponse placeOrder(PlaceOrderRequest req, OrderType type) {
        ReentrantLock lock = stockLocks.computeIfAbsent(
                req.getSymbol().toUpperCase(), k -> new ReentrantLock(true));
        lock.lock();
        try {
            return executeOrderTransaction(req, type);
        } finally {
            lock.unlock();
        }
    }

    @Transactional
    protected OrderResponse executeOrderTransaction(PlaceOrderRequest req, OrderType type) {
        User  user  = userService.findOrThrow(req.getUserId());
        Stock stock = stockService.findOrThrow(req.getSymbol());

        // Persist the incoming order
        Order incomingOrder = Order.builder()
                .user(user)
                .stock(stock)
                .orderType(type)
                .price(req.getPrice())
                .quantity(req.getQuantity())
                .remainingQuantity(req.getQuantity())
                .status(OrderStatus.OPEN)
                .build();
        incomingOrder = orderRepository.save(incomingOrder);

        // Run the matching loop
        matchOrder(incomingOrder, stock);

        return toResponse(incomingOrder);
    }

    /**
     * Price-time priority matching loop.
     *
     * BUY  order: look for SELL orders whose price ≤ buyPrice  (ascending price, then FIFO)
     * SELL order: look for BUY  orders whose price ≥ sellPrice (descending price, then FIFO)
     */
    private void matchOrder(Order incoming, Stock stock) {
        if (incoming.getRemainingQuantity() <= 0) return;

        List<Order> counterOrders = (incoming.getOrderType() == OrderType.BUY)
                ? orderRepository.findMatchingSellOrders(stock, incoming.getPrice())
                : orderRepository.findMatchingBuyOrders(stock, incoming.getPrice());

        List<Trade> tradesBuffer = new ArrayList<>();

        for (Order counter : counterOrders) {
            if (incoming.getRemainingQuantity() <= 0) break;

            int matchQty = Math.min(incoming.getRemainingQuantity(), counter.getRemainingQuantity());
            BigDecimal tradePrice = counter.getPrice(); // passive order's price is the execution price

            Order buyOrder  = (incoming.getOrderType() == OrderType.BUY) ? incoming : counter;
            Order sellOrder = (incoming.getOrderType() == OrderType.SELL) ? incoming : counter;

            // Update remaining quantities
            incoming.setRemainingQuantity(incoming.getRemainingQuantity() - matchQty);
            counter.setRemainingQuantity(counter.getRemainingQuantity() - matchQty);

            // Update statuses
            incoming.setStatus(incoming.getRemainingQuantity() == 0 ? OrderStatus.FILLED : OrderStatus.PARTIAL);
            counter.setStatus(counter.getRemainingQuantity() == 0 ? OrderStatus.FILLED : OrderStatus.PARTIAL);

            // Buffer trade record
            tradesBuffer.add(Trade.builder()
                    .buyOrder(buyOrder)
                    .sellOrder(sellOrder)
                    .price(tradePrice)
                    .quantity(matchQty)
                    .build());

            log.info("Trade matched: buy_order={} sell_order={} qty={} price={}",
                    buyOrder.getId(), sellOrder.getId(), matchQty, tradePrice);
        }

        // Batch-save all updated counter orders & trades
        if (!tradesBuffer.isEmpty()) {
            // counter orders were modified; collect unique instances
            Set<Long> counterIds = tradesBuffer.stream()
                    .map(t -> {
                        Order c = (incoming.getOrderType() == OrderType.BUY) ? t.getSellOrder() : t.getBuyOrder();
                        orderRepository.save(c);
                        return c.getId();
                    })
                    .collect(Collectors.toSet());
            orderRepository.save(incoming);
            tradeRepository.saveAll(tradesBuffer);
            log.info("Persisted {} trade(s) for order {}", tradesBuffer.size(), incoming.getId());
        }
    }

    // ── Market depth aggregation ──────────────────────────────────────────────

    private List<OrderBookEntry> aggregateEntries(List<Order> orders) {
        Map<BigDecimal, int[]> priceMap = new LinkedHashMap<>();
        for (Order o : orders) {
            priceMap.computeIfAbsent(o.getPrice(), k -> new int[]{0, 0});
            priceMap.get(o.getPrice())[0] += o.getRemainingQuantity();
            priceMap.get(o.getPrice())[1]++;
        }
        return priceMap.entrySet().stream()
                .map(e -> OrderBookEntry.builder()
                        .price(e.getKey())
                        .totalQuantity(e.getValue()[0])
                        .orderCount(e.getValue()[1])
                        .build())
                .collect(Collectors.toList());
    }

    // ── Response mapping ──────────────────────────────────────────────────────

    public OrderResponse toResponse(Order o) {
        return OrderResponse.builder()
                .id(o.getId())
                .userId(o.getUser().getId())
                .userName(o.getUser().getName())
                .stockSymbol(o.getStock().getSymbol())
                .orderType(o.getOrderType())
                .price(o.getPrice())
                .quantity(o.getQuantity())
                .remainingQuantity(o.getRemainingQuantity())
                .status(o.getStatus())
                .createdAt(o.getCreatedAt())
                .build();
    }
}
